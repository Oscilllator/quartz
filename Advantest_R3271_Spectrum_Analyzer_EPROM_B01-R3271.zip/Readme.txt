Firmware version: on eprom labels B01, inside eprom code A12

U28.bin		27C2001
U30.bin		27C2001
U29.bin		27C2001
U31.bin		27C2001
